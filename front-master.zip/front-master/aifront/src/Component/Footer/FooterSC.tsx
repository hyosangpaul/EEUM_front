import styled from "styled-components";

export const Footer = styled.footer`
    padding : 2em;
    background-Color : #C996CC;
    color : white;
`